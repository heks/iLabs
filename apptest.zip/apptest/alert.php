<?php
echo $_POST['content'];
?>