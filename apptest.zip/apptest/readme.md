**Click below to read important background information involved in this lab.**

* How does this lab work?
* What is Strontium-90?
* What is radiation?
* What is radioactivity, or radioactive decay?
* How is radioactivity measured?

<textarea>hjdsgfhjgshj</textarea>

<textarea>nmnnknknk</textarea>