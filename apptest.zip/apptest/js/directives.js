/* Directives */
/*angular.module('mobileApp', []).directive('markdown', function(){
  var converter = new Showdown.converter();
  return{
    restrict: 'E',
    link: function(scope, element, attrs){
      var htmlText = converter.makeHtml(element.text());
      element.html(htmlText);
    }
  }
});*/
/*var myApp = angular.module('mobileApp', []).run(function($rootScope, $location) {
    $rootScope.location = $location;
});*/

/*var app = angular.module('mobileApp', []);

app.directive('myDirective', function () {
    return {
      restrict: 'C',
      scope: {
        options: '='
      },
      link: function (scope) {
        scope.$watch('options.reload', function (val) {
          if (val) {
            alert('reloading')
            scope.options.reload = false
          }
        })
        scope.$watch('options.refresh', function (val) {
          if (val) {
            alert('refreshing')
            scope.options.refresh = false
          }
        })
      }
    }
  })
  .controller('appController', function ($scope) {
    $scope.opts = {
      reload: false,
      refresh: false
    }
    
   //$scope.reload = function () {
      $scope.opts.reload = true
   // }
    
    $scope.refresh = function () {
      $scope.opts.refresh = true
    }
  })*/
/*angular.module('mobileApp', ['pascalprecht.translate'], ['$translateProvider', function ($translateProvider) {
  // register german translation table
  $translateProvider.translations('de_DE', {
    'GREETING': 'Hallo Welt!'
  });
  // register english translation table
  $translateProvider.translations('en_EN', {
    'GREETING': 'Hello World!'
  });
  // which language to use?
  $translateProvider.uses('de_DE');
}]);

angular.module('mobileApp').controller('appController', ['$translate', '$scope', function ($translate, $scope) {

  $scope.toggleLanguage = function () {
    $translate.uses(($translate.uses() === 'en_EN') ? 'de_DE' : 'en_EN');
  };

}]);*/